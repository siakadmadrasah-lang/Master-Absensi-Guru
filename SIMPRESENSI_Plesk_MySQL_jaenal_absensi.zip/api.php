<?php
/**
 * SIMPRESENSI GTK MADRASAH - PLESK PHP BACKEND API & SYNC
 * Konfigurasi Database MySQL Plesk
 */

// 1. CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 2. Kredensial Database MySQL Sesuai Konfigurasi Plesk
define('DB_HOST', 'localhost');
define('DB_USER', 'jaenal_absensi');
define('DB_PASS', 'masbagus15');
define('DB_NAME', 'jaenal_absensi');

// 3. Inisialisasi PDO MySQL
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Koneksi Database MySQL Gagal. Pastikan database jaenal_absensi sudah dibuat di Plesk.',
        'error' => $e->getMessage()
    ]);
    exit;
}

// 4. Router API
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($action) {
    case 'test_db':
    case 'health':
        try {
            $stmt = $pdo->query("SELECT 1 as test, NOW() as server_time");
            $res = $stmt->fetch();
            echo json_encode([
                'success' => true,
                'status' => 'ok',
                'service' => 'simpresensi-mysql-plesk',
                'message' => 'Koneksi database MySQL Plesk (jaenal_absensi) BERHASIL!',
                'server_time' => $res['server_time']
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'version':
        try {
            $stmt = $pdo->query("SELECT MAX(updated_at) as last_updated FROM madrasah_profile");
            $res = $stmt->fetch();
            $lastUp = $res && $res['last_updated'] ? strtotime($res['last_updated']) : time();
            echo json_encode([
                'success' => true,
                'version' => $lastUp,
                'lastUpdated' => $lastUp * 1000
            ]);
        } catch (Exception $e) {
            echo json_encode(['success' => true, 'version' => time(), 'lastUpdated' => time() * 1000]);
        }
        break;

    case 'get_initial_data':
    case 'data':
        if ($method === 'POST') {
            // Forward to save all data
            goto do_sync_save;
        }
        try {
            $profileStmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
            $profile = $profileStmt->fetch();
            if ($profile && !empty($profile['raw_json'])) {
                $profileData = json_decode($profile['raw_json'], true);
            } else {
                $profileData = $profile;
            }

            $scheduleStmt = $pdo->query("SELECT * FROM work_schedules LIMIT 1");
            $sched = $scheduleStmt->fetch();
            $scheduleData = ($sched && !empty($sched['raw_json'])) ? json_decode($sched['raw_json'], true) : null;

            $teachersStmt = $pdo->query("SELECT * FROM teachers ORDER BY role DESC, name ASC");
            $teachers = $teachersStmt->fetchAll();

            $holidaysStmt = $pdo->query("SELECT * FROM holidays ORDER BY date ASC");
            $holidays = $holidaysStmt->fetchAll();

            $attendanceStmt = $pdo->query("SELECT id, teacherId, date, checkInTime, checkOutTime, status, method as verificationMethod, lateMinutes, earlyMinutes as earlyLeaveMinutes, notes FROM attendance_records ORDER BY date DESC, checkInTime DESC LIMIT 3000");
            $attendance = $attendanceStmt->fetchAll();

            $leaveStmt = $pdo->query("SELECT * FROM leave_requests ORDER BY createdAt DESC");
            $leaves = $leaveStmt->fetchAll();

            echo json_encode([
                'success' => true,
                'data' => [
                    'profile' => $profileData,
                    'schedule' => $scheduleData,
                    'teachers' => $teachers,
                    'holidays' => $holidays,
                    'attendanceRecords' => $attendance,
                    'leaveRequests' => $leaves,
                    'version' => time()
                ]
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'sync':
    case 'save_all_data':
        do_sync_save:
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
            exit;
        }
        try {
            $pdo->beginTransaction();

            // 1. Save Profile
            if (!empty($body['profile'])) {
                $p = $body['profile'];
                $pSql = "INSERT INTO madrasah_profile (id, name, nsm, npsn, level, status, address, village, district, regency, province, postalCode, phone, email, website, headmasterName, headmasterNip, operatorName, raw_json)
                         VALUES (1, :name, :nsm, :npsn, :level, :status, :address, :village, :district, :regency, :province, :postalCode, :phone, :email, :website, :headmasterName, :headmasterNip, 'Jaenal Maskun', :raw_json)
                         ON DUPLICATE KEY UPDATE 
                         name=VALUES(name), nsm=VALUES(nsm), npsn=VALUES(npsn), headmasterName=VALUES(headmasterName), raw_json=VALUES(raw_json)";
                $pStmt = $pdo->prepare($pSql);
                $pStmt->execute([
                    ':name' => $p['name'] ?? 'Madrasah',
                    ':nsm' => $p['nsm'] ?? '',
                    ':npsn' => $p['npsn'] ?? '',
                    ':level' => $p['level'] ?? 'MI',
                    ':status' => $p['status'] ?? 'SWASTA',
                    ':address' => $p['address'] ?? '',
                    ':village' => $p['village'] ?? '',
                    ':district' => $p['district'] ?? '',
                    ':regency' => $p['city'] ?? $p['regency'] ?? '',
                    ':province' => $p['province'] ?? '',
                    ':postalCode' => $p['postalCode'] ?? '',
                    ':phone' => $p['phone'] ?? '',
                    ':email' => $p['email'] ?? '',
                    ':website' => $p['website'] ?? '',
                    ':headmasterName' => $p['headmasterName'] ?? 'Kepala Madrasah',
                    ':headmasterNip' => $p['headmasterNip'] ?? '-',
                    ':raw_json' => json_encode($p)
                ]);

                // Persist uploaded thumbnail & favicon to physical disk files
                if (!empty($p['ogImageUrl']) && strpos($p['ogImageUrl'], 'data:image') === 0) {
                    $ogParts = explode(',', $p['ogImageUrl']);
                    if (count($ogParts) === 2) {
                        $ogBinary = base64_decode($ogParts[1]);
                        @file_put_contents(__DIR__ . '/og-image.jpg', $ogBinary);
                        @file_put_contents(__DIR__ . '/og-image.png', $ogBinary);
                    }
                }
                if (!empty($p['faviconUrl']) && strpos($p['faviconUrl'], 'data:image') === 0) {
                    $favParts = explode(',', $p['faviconUrl']);
                    if (count($favParts) === 2) {
                        $favBinary = base64_decode($favParts[1]);
                        @file_put_contents(__DIR__ . '/favicon.png', $favBinary);
                        @file_put_contents(__DIR__ . '/favicon.ico', $favBinary);
                    }
                }
            }

            // 2. Save Teachers (and delete removed teachers from MySQL)
            if (isset($body['teachers']) && is_array($body['teachers'])) {
                $teachersList = $body['teachers'];
                $validIds = [];
                foreach ($teachersList as $t) {
                    if (!empty($t['id'])) $validIds[] = $t['id'];
                }

                // Aman: Hanya lakukan Upsert (INSERT/UPDATE), jangan pernah hapus data guru lama saat timpa
                $tSql = "INSERT INTO teachers (id, fingerprintId, nik, nip, nuptk, pegId, name, title, position, employmentStatus, role, pin, gender, phone, email, teachingHoursPerWeek, isBiometricEnrolled, avatarColor, isActive)
                         VALUES (:id, :fingerprintId, :nik, :nip, :nuptk, :pegId, :name, :title, :position, :employmentStatus, :role, :pin, :gender, :phone, :email, :teachingHoursPerWeek, :isBiometricEnrolled, :avatarColor, :isActive)
                         ON DUPLICATE KEY UPDATE 
                         fingerprintId=VALUES(fingerprintId), nik=VALUES(nik), nip=VALUES(nip), nuptk=VALUES(nuptk), pegId=VALUES(pegId), name=VALUES(name), title=VALUES(title), position=VALUES(position), employmentStatus=VALUES(employmentStatus), role=VALUES(role), pin=VALUES(pin), gender=VALUES(gender), phone=VALUES(phone), email=VALUES(email), teachingHoursPerWeek=VALUES(teachingHoursPerWeek), isBiometricEnrolled=VALUES(isBiometricEnrolled), avatarColor=VALUES(avatarColor), isActive=VALUES(isActive)";
                $tStmt = $pdo->prepare($tSql);
                foreach ($teachersList as $t) {
                    if (empty($t['id'])) continue;
                    $tStmt->execute([
                        ':id' => $t['id'],
                        ':fingerprintId' => $t['fingerprintId'] ?? 0,
                        ':nik' => $t['nik'] ?? $t['id'],
                        ':nip' => $t['nip'] ?? '-',
                        ':nuptk' => $t['nuptk'] ?? '-',
                        ':pegId' => $t['pegId'] ?? '-',
                        ':name' => $t['name'] ?? 'Guru',
                        ':title' => $t['title'] ?? '',
                        ':position' => $t['position'] ?? 'Guru',
                        ':employmentStatus' => $t['employmentStatus'] ?? 'GTY',
                        ':role' => $t['role'] ?? 'GURU',
                        ':pin' => $t['pin'] ?? '123456',
                        ':gender' => $t['gender'] ?? 'L',
                        ':phone' => $t['phone'] ?? '-',
                        ':email' => $t['email'] ?? '',
                        ':teachingHoursPerWeek' => $t['teachingHoursPerWeek'] ?? 24,
                        ':isBiometricEnrolled' => !empty($t['isBiometricEnrolled']) ? 1 : 0,
                        ':avatarColor' => $t['avatarColor'] ?? 'bg-emerald-700',
                        ':isActive' => isset($t['isActive']) && !$t['isActive'] ? 0 : 1
                    ]);
                }
            }

            // 3. Save Schedule
            if (!empty($body['schedule'])) {
                $s = $body['schedule'];
                $sSql = "INSERT INTO work_schedules (id, workDaysCount, toleranceMinutes, raw_json)
                         VALUES (1, :workDaysCount, :toleranceMinutes, :raw_json)
                         ON DUPLICATE KEY UPDATE 
                         workDaysCount=VALUES(workDaysCount), toleranceMinutes=VALUES(toleranceMinutes), raw_json=VALUES(raw_json)";
                $sStmt = $pdo->prepare($sSql);
                $sStmt->execute([
                    ':workDaysCount' => $s['workDaysCount'] ?? 6,
                    ':toleranceMinutes' => $s['toleranceMinutes'] ?? 5,
                    ':raw_json' => json_encode($s)
                ]);
            }

            // 4. Save Attendance Records
            if (isset($body['attendanceRecords']) && is_array($body['attendanceRecords'])) {
                $attSql = "INSERT INTO attendance_records 
                           (id, teacherId, date, checkInTime, checkOutTime, status, method, lateMinutes, earlyMinutes, notes)
                           VALUES (:id, :teacherId, :date, :checkInTime, :checkOutTime, :status, :method, :lateMinutes, :earlyMinutes, :notes)
                           ON DUPLICATE KEY UPDATE 
                           checkInTime = VALUES(checkInTime),
                           checkOutTime = VALUES(checkOutTime),
                           status = VALUES(status),
                           method = VALUES(method),
                           lateMinutes = VALUES(lateMinutes),
                           earlyMinutes = VALUES(earlyMinutes),
                           notes = VALUES(notes)";
                $attStmt = $pdo->prepare($attSql);
                foreach ($body['attendanceRecords'] as $att) {
                    if (empty($att['id']) || empty($att['teacherId']) || empty($att['date'])) continue;
                    $attStmt->execute([
                        ':id' => $att['id'],
                        ':teacherId' => $att['teacherId'],
                        ':date' => $att['date'],
                        ':checkInTime' => $att['checkInTime'] ?? null,
                        ':checkOutTime' => $att['checkOutTime'] ?? null,
                        ':status' => $att['status'] ?? 'HADIR',
                        ':method' => $att['verificationMethod'] ?? $att['method'] ?? 'FINGERPRINT',
                        ':lateMinutes' => $att['lateMinutes'] ?? 0,
                        ':earlyMinutes' => $att['earlyLeaveMinutes'] ?? $att['earlyMinutes'] ?? 0,
                        ':notes' => $att['notes'] ?? ''
                    ]);
                }
            }

            // 5. Save Leave Requests
            if (isset($body['leaveRequests']) && is_array($body['leaveRequests'])) {
                $leaveSql = "INSERT INTO leave_requests 
                             (id, teacherId, type, startDate, endDate, reason, status, approvedBy)
                             VALUES (:id, :teacherId, :type, :startDate, :endDate, :reason, :status, :approvedBy)
                             ON DUPLICATE KEY UPDATE 
                             type = VALUES(type),
                             startDate = VALUES(startDate),
                             endDate = VALUES(endDate),
                             reason = VALUES(reason),
                             status = VALUES(status),
                             approvedBy = VALUES(approvedBy)";
                $leaveStmt = $pdo->prepare($leaveSql);
                foreach ($body['leaveRequests'] as $lr) {
                    if (empty($lr['id']) || empty($lr['teacherId'])) continue;
                    $leaveStmt->execute([
                        ':id' => $lr['id'],
                        ':teacherId' => $lr['teacherId'],
                        ':type' => $lr['type'] ?? 'IZIN',
                        ':startDate' => $lr['startDate'] ?? date('Y-m-d'),
                        ':endDate' => $lr['endDate'] ?? date('Y-m-d'),
                        ':reason' => $lr['reason'] ?? 'Izin',
                        ':status' => $lr['status'] ?? 'APPROVED',
                        ':approvedBy' => $lr['approvedBy'] ?? 'Kepala Madrasah'
                    ]);
                }
            }

            // 6. Save Holidays
            if (isset($body['holidays']) && is_array($body['holidays'])) {
                $hSql = "INSERT INTO holidays (id, date, name, type)
                         VALUES (:id, :date, :name, :type)
                         ON DUPLICATE KEY UPDATE name=VALUES(name), type=VALUES(type)";
                $hStmt = $pdo->prepare($hSql);
                foreach ($body['holidays'] as $h) {
                    if (empty($h['id']) || empty($h['date'])) continue;
                    $hStmt->execute([
                        ':id' => $h['id'],
                        ':date' => $h['date'],
                        ':name' => $h['name'] ?? 'Hari Libur',
                        ':type' => $h['type'] ?? 'NASIONAL'
                    ]);
                }
            }

            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Sinkronisasi data ke MySQL Plesk berhasil!',
                'version' => time(),
                'lastUpdated' => time() * 1000
            ]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'delete_teacher':
        $delId = $_GET['id'] ?? $body['id'] ?? '';
        if (!empty($delId) && $delId !== 'super-admin-jaenal') {
            try {
                $stmt = $pdo->prepare("DELETE FROM teachers WHERE id = :id");
                $stmt->execute([':id' => $delId]);
                echo json_encode(['success' => true, 'message' => 'Data GTK berhasil dihapus permanen dari database MySQL']);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID GTK tidak valid atau dilindungi']);
        }
        break;

    case 'teachers':
        if ($method === 'GET') {
            try {
                $stmt = $pdo->query("SELECT * FROM teachers ORDER BY role DESC, name ASC");
                $teachers = $stmt->fetchAll();
                echo json_encode(['success' => true, 'teachers' => $teachers, 'version' => time()]);
            } catch (Exception $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
        } else if ($method === 'POST') {
            try {
                $teachers = $body['teachers'] ?? $body;
                if (!is_array($teachers)) throw new Exception('Format data harus array');
                $pdo->beginTransaction();

                $validIds = [];
                foreach ($teachers as $t) {
                    if (!empty($t['id'])) $validIds[] = $t['id'];
                }

                // Aman: Hanya lakukan Upsert (INSERT/UPDATE), tidak menghapus guru lama
                $tSql = "INSERT INTO teachers (id, fingerprintId, nik, nip, nuptk, pegId, name, title, position, employmentStatus, role, pin, gender, phone, email, teachingHoursPerWeek, isBiometricEnrolled, avatarColor, isActive)
                         VALUES (:id, :fingerprintId, :nik, :nip, :nuptk, :pegId, :name, :title, :position, :employmentStatus, :role, :pin, :gender, :phone, :email, :teachingHoursPerWeek, :isBiometricEnrolled, :avatarColor, :isActive)
                         ON DUPLICATE KEY UPDATE 
                         fingerprintId=VALUES(fingerprintId), nik=VALUES(nik), nip=VALUES(nip), nuptk=VALUES(nuptk), pegId=VALUES(pegId), name=VALUES(name), title=VALUES(title), position=VALUES(position), employmentStatus=VALUES(employmentStatus), role=VALUES(role), pin=VALUES(pin), gender=VALUES(gender), phone=VALUES(phone), email=VALUES(email), teachingHoursPerWeek=VALUES(teachingHoursPerWeek), isBiometricEnrolled=VALUES(isBiometricEnrolled), avatarColor=VALUES(avatarColor), isActive=VALUES(isActive)";
                $tStmt = $pdo->prepare($tSql);
                foreach ($teachers as $t) {
                    if (empty($t['id'])) continue;
                    $tStmt->execute([
                        ':id' => $t['id'],
                        ':fingerprintId' => $t['fingerprintId'] ?? 0,
                        ':nik' => $t['nik'] ?? $t['id'],
                        ':nip' => $t['nip'] ?? '-',
                        ':nuptk' => $t['nuptk'] ?? '-',
                        ':pegId' => $t['pegId'] ?? '-',
                        ':name' => $t['name'] ?? 'Guru',
                        ':title' => $t['title'] ?? '',
                        ':position' => $t['position'] ?? 'Guru',
                        ':employmentStatus' => $t['employmentStatus'] ?? 'GTY',
                        ':role' => $t['role'] ?? 'GURU',
                        ':pin' => $t['pin'] ?? '123456',
                        ':gender' => $t['gender'] ?? 'L',
                        ':phone' => $t['phone'] ?? '-',
                        ':email' => $t['email'] ?? '',
                        ':teachingHoursPerWeek' => $t['teachingHoursPerWeek'] ?? 24,
                        ':isBiometricEnrolled' => !empty($t['isBiometricEnrolled']) ? 1 : 0,
                        ':avatarColor' => $t['avatarColor'] ?? 'bg-emerald-700',
                        ':isActive' => isset($t['isActive']) && !$t['isActive'] ? 0 : 1
                    ]);
                }
                $pdo->commit();
                echo json_encode(['success' => true, 'message' => 'Data guru berhasil diperbarui di MySQL!']);
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
        }
        break;

    case 'save_record':
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
            exit;
        }
        try {
            $sql = "INSERT INTO attendance_records 
                    (id, teacherId, date, checkInTime, checkOutTime, status, method, lateMinutes, earlyMinutes, notes, deviceIp)
                    VALUES (:id, :teacherId, :date, :checkInTime, :checkOutTime, :status, :method, :lateMinutes, :earlyMinutes, :notes, :deviceIp)
                    ON DUPLICATE KEY UPDATE 
                    checkInTime = VALUES(checkInTime),
                    checkOutTime = VALUES(checkOutTime),
                    status = VALUES(status),
                    lateMinutes = VALUES(lateMinutes),
                    earlyMinutes = VALUES(earlyMinutes),
                    notes = VALUES(notes)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $body['id'] ?? uniqid('att-'),
                ':teacherId' => $body['teacherId'] ?? '',
                ':date' => $body['date'] ?? date('Y-m-d'),
                ':checkInTime' => $body['checkInTime'] ?? null,
                ':checkOutTime' => $body['checkOutTime'] ?? null,
                ':status' => $body['status'] ?? 'HADIR',
                ':method' => $body['verificationMethod'] ?? $body['method'] ?? 'FINGERPRINT',
                ':lateMinutes' => $body['lateMinutes'] ?? 0,
                ':earlyMinutes' => $body['earlyLeaveMinutes'] ?? $body['earlyMinutes'] ?? 0,
                ':notes' => $body['notes'] ?? '',
                ':deviceIp' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);
            echo json_encode([
                'success' => true, 
                'message' => 'Presensi berhasil disimpan ke MySQL!',
                'version' => time(),
                'lastUpdated' => time() * 1000
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'login':
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
            exit;
        }
        $identifier = trim($body['identifier'] ?? '');
        $pin = trim($body['pin'] ?? '');

        // Super Admin Hardcoded / DB check
        if (($identifier === 'jaenalmaskun@gmail.com' || $identifier === 'jaenalmaskun' || $identifier === 'superadmin') && ($pin === 'masbagus' || $pin === '999999')) {
            echo json_encode([
                'success' => true,
                'user' => [
                    'id' => 'super-admin-jaenal',
                    'fingerprintId' => 999,
                    'nik' => '3302010000009999',
                    'name' => 'Jaenal Maskun',
                    'title' => 'S.Pd.I.',
                    'position' => 'Super Administrator SIMPRESENSI',
                    'employmentStatus' => 'TENAGA_KEPENDIDIKAN',
                    'role' => 'ADMIN',
                    'gender' => 'L',
                    'phone' => '081234567890',
                    'email' => 'jaenalmaskun@gmail.com',
                    'avatarColor' => 'bg-emerald-800',
                    'isActive' => true
                ]
            ]);
            exit;
        }

        try {
            $stmt = $pdo->prepare("SELECT * FROM teachers WHERE (nik = :ident OR email = :ident OR nip = :ident OR pegId = :ident OR nuptk = :ident OR fingerprintId = :ident) AND (pin = :pin OR (pin IS NULL AND :pin = '123456') OR (pin = '' AND :pin = '123456')) LIMIT 1");
            $stmt->execute([':ident' => $identifier, ':pin' => $pin]);
            $user = $stmt->fetch();
            if ($user) {
                echo json_encode(['success' => true, 'user' => $user]);
            } else {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Email/NIK/NIP/Peg ID atau PIN tidak cocok']);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'upload_og_image':
    case 'upload-og-image':
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
            exit;
        }
        try {
            $imageDataUrl = $body['imageDataUrl'] ?? '';
            if (empty($imageDataUrl) || strpos($imageDataUrl, 'data:image') !== 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Format gambar base64 tidak valid']);
                exit;
            }
            $parts = explode(',', $imageDataUrl);
            if (count($parts) === 2) {
                $bin = base64_decode($parts[1]);
                @file_put_contents(__DIR__ . '/og-image.jpg', $bin);
                @file_put_contents(__DIR__ . '/og-image.png', $bin);
            }

            // Update madrasah_profile in MySQL
            $profileStmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
            $profile = $profileStmt->fetch();
            $pData = [];
            if ($profile && !empty($profile['raw_json'])) {
                $pData = json_decode($profile['raw_json'], true) ?: [];
            }
            $pData['ogImageUrl'] = $imageDataUrl;
            $newJson = json_encode($pData);

            $updateStmt = $pdo->prepare("UPDATE madrasah_profile SET raw_json = :json WHERE id = 1");
            $updateStmt->execute([':json' => $newJson]);

            echo json_encode([
                'success' => true,
                'message' => 'Thumbnail banner berhasil diunggah & disimpan di server!',
                'version' => time()
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'og_image':
    case 'og-image':
    case 'og_image.jpg':
    case 'og-image.jpg':
        try {
            $profileStmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
            $profile = $profileStmt->fetch();
            if ($profile && !empty($profile['raw_json'])) {
                $pData = json_decode($profile['raw_json'], true);
                if (!empty($pData['ogImageUrl']) && strpos($pData['ogImageUrl'], 'data:image') === 0) {
                    $parts = explode(',', $pData['ogImageUrl']);
                    if (count($parts) === 2) {
                        $mime = 'image/jpeg';
                        if (preg_match('/^data:([^;]+);base64,/', $pData['ogImageUrl'], $m)) {
                            $mime = $m[1];
                        }
                        header('Content-Type: ' . $mime);
                        header('Cache-Control: public, max-age=60, s-maxage=60, stale-while-revalidate=120');
                        header('Accept-Ranges: bytes');
                        echo base64_decode($parts[1]);
                        exit;
                    }
                }
            }
            if (file_exists(__DIR__ . '/og-image.jpg')) {
                header('Content-Type: image/jpeg');
                header('Cache-Control: public, max-age=60, s-maxage=60, stale-while-revalidate=120');
                header('Accept-Ranges: bytes');
                readfile(__DIR__ . '/og-image.jpg');
                exit;
            }
            if (file_exists(__DIR__ . '/og-image.png')) {
                header('Content-Type: image/png');
                header('Cache-Control: public, max-age=60, s-maxage=60, stale-while-revalidate=120');
                header('Accept-Ranges: bytes');
                readfile(__DIR__ . '/og-image.png');
                exit;
            }
            http_response_code(404);
            echo "Not Found";
        } catch (Exception $e) {
            http_response_code(500);
            echo "Error";
        }
        exit;

    case 'favicon':
    case 'favicon.ico':
    case 'favicon.png':
        try {
            $profileStmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
            $profile = $profileStmt->fetch();
            if ($profile && !empty($profile['raw_json'])) {
                $pData = json_decode($profile['raw_json'], true);
                if (!empty($pData['faviconUrl']) && strpos($pData['faviconUrl'], 'data:image') === 0) {
                    $parts = explode(',', $pData['faviconUrl']);
                    if (count($parts) === 2) {
                        header('Content-Type: image/png');
                        header('Cache-Control: public, max-age=3600');
                        echo base64_decode($parts[1]);
                        exit;
                    }
                }
            }
            if (file_exists(__DIR__ . '/favicon.png')) {
                header('Content-Type: image/png');
                header('Cache-Control: public, max-age=3600');
                readfile(__DIR__ . '/favicon.png');
                exit;
            }
            if (file_exists(__DIR__ . '/favicon.ico')) {
                header('Content-Type: image/x-icon');
                header('Cache-Control: public, max-age=3600');
                readfile(__DIR__ . '/favicon.ico');
                exit;
            }
            http_response_code(404);
            echo "Not Found";
        } catch (Exception $e) {
            http_response_code(500);
            echo "Error";
        }
        exit;

    default:
        echo json_encode([
            'success' => true,
            'name' => 'SIMPRESENSI Madrasah API',
            'version' => '2.5.0',
            'database' => 'MySQL (Plesk jaenal_absensi)',
            'endpoints' => [
                'GET ?action=test_db',
                'GET ?action=get_initial_data',
                'POST ?action=sync',
                'GET / POST ?action=teachers',
                'POST ?action=save_record',
                'POST ?action=login',
                'GET ?action=version'
            ]
        ]);
        break;
}
