<?php
/**
 * SIMPRESENSI GTK MADRASAH - cPanel PHP & MySQL REST API Backend
 * Database User: masbagoes_absensi
 * Database Name: masbagoes_absensi
 * Database Pass: masbagus15
 * Database Host: localhost
 */

// 1. CORS & Response Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 2. Kredensial Database MySQL cPanel
define('DB_HOST', 'localhost');
define('DB_USER', 'masbagoes_absensi');
define('DB_PASS', 'masbagus15');
define('DB_NAME', 'masbagoes_absensi');

// 3. Inisialisasi Koneksi PDO
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Koneksi Database MySQL cPanel Gagal. Pastikan database masbagoes_absensi dan user masbagoes_absensi telah dibuat di cPanel MySQL Databases dan diberi ALL PRIVILEGES.',
        'error' => $e->getMessage()
    ]);
    exit;
}

// 4. Router API
$rawAction = $_GET['action'] ?? $_POST['action'] ?? $body['action'] ?? '';
$action = strtolower(trim($rawAction));
$method = $_SERVER['REQUEST_METHOD'];
$body = json_decode(file_get_contents('php://input'), true) ?? [];

// Tampilan visual ramah browser jika diakses via web browser langsung untuk Uji Koneksi
if ($method === 'GET' && in_array($action, ['', 'test', 'test_db', 'test-connection', 'uji_koneksi', 'uji-koneksi', 'status', 'health']) && strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'text/html') !== false) {
    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html lang='id'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'><title>Status API cPanel - SIMPRESENSI</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#090d16;color:#f1f5f9;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px;box-sizing:border-box}.card{background:#0f172a;border:1px solid #10b981;border-radius:16px;padding:32px;max-width:560px;width:100%;box-shadow:0 20px 25px -5px rgba(0,0,0,0.5)}.badge{background:#064e3b;color:#34d399;font-size:12px;font-weight:700;padding:4px 12px;border-radius:9999px;display:inline-block;margin-bottom:12px}.title{font-size:20px;font-weight:800;margin:0 0 8px 0;color:#ffffff}.desc{color:#94a3b8;font-size:14px;margin-bottom:24px;line-height:1.5}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:24px}.item{background:#1e293b;padding:12px;border-radius:8px}.label{font-size:11px;color:#94a3b8}.val{font-size:13px;font-weight:700;color:#38bdf8;font-family:monospace;margin-top:2px}.success{background:#10b981;color:#022c22;padding:12px;border-radius:8px;font-weight:700;text-align:center;font-size:14px}</style></head><body><div class='card'><span class='badge'>AKTIF & TERHUBUNG</span><h1 class='title'>Uji Koneksi API cPanel Berhasil!</h1><p class='desc'>Endpoint REST API backend PHP dan Database MySQL cPanel siap melayani aplikasi SIMPRESENSI Madrasah.</p><div class='grid'><div class='item'><div class='label'>Database Name</div><div class='val'>" . DB_NAME . "</div></div><div class='item'><div class='label'>Database User</div><div class='val'>" . DB_USER . "</div></div><div class='item'><div class='label'>Database Host</div><div class='val'>" . DB_HOST . "</div></div><div class='item'><div class='label'>Status Koneksi</div><div class='val' style='color:#34d399'>Terhubung (200 OK)</div></div></div><div class='success'>✓ Endpoint API cPanel Ditemukan & Siap Digunakan</div></div></body></html>";
    exit;
}

switch ($action) {
    case '':
    case 'test':
    case 'test_db':
    case 'test-connection':
    case 'test_connection':
    case 'uji_koneksi':
    case 'uji-koneksi':
    case 'uji':
    case 'koneksi':
    case 'health':
    case 'ping':
    case 'status':
    case 'check':
        try {
            $stmt = $pdo->query("SELECT 1 as test, NOW() as server_time, DATABASE() as current_db");
            $res = $stmt->fetch();
            echo json_encode([
                'success' => true,
                'status' => 'ok',
                'service' => 'simpresensi-cpanel-mysql',
                'message' => 'Uji Koneksi API cPanel & Database MySQL (masbagoes_absensi) BERHASIL & DITEMUKAN!',
                'database' => $res['current_db'] ?: 'masbagoes_absensi',
                'user' => 'masbagoes_absensi',
                'host' => 'localhost',
                'server_time' => $res['server_time']
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Gagal koneksi database MySQL: ' . $e->getMessage()
            ]);
        }
        break;

    case 'version':
        try {
            $stmt = $pdo->query("SELECT MAX(updated_at) as last_updated FROM madrasah_profile");
            $res = $stmt->fetch();
            $lastUp = $res && $res['last_updated'] ? strtotime($res['last_updated']) : time();
            echo json_encode([
                'success' => true,
                'version' => $lastUp,
                'lastUpdated' => $lastUp * 1000
            ]);
        } catch (Exception $e) {
            echo json_encode(['success' => true, 'version' => time(), 'lastUpdated' => time() * 1000]);
        }
        break;

    case 'get_initial_data':
    case 'data':
        if ($method === 'POST') {
            goto do_sync_save;
        }
        try {
            $profileStmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
            $profile = $profileStmt->fetch();
            $profileData = ($profile && !empty($profile['raw_json'])) ? json_decode($profile['raw_json'], true) : $profile;

            $scheduleStmt = $pdo->query("SELECT * FROM work_schedules LIMIT 1");
            $sched = $scheduleStmt->fetch();
            $scheduleData = ($sched && !empty($sched['raw_json'])) ? json_decode($sched['raw_json'], true) : null;

            $teachersStmt = $pdo->query("SELECT * FROM teachers ORDER BY role DESC, name ASC");
            $teachers = $teachersStmt->fetchAll();

            $holidaysStmt = $pdo->query("SELECT * FROM holidays ORDER BY date ASC");
            $holidays = $holidaysStmt->fetchAll();

            $attendanceStmt = $pdo->query("SELECT id, teacherId, date, checkInTime, checkOutTime, status, method as verificationMethod, lateMinutes, earlyMinutes as earlyLeaveMinutes, notes FROM attendance_records ORDER BY date DESC, checkInTime DESC LIMIT 5000");
            $attendance = $attendanceStmt->fetchAll();

            $leaveStmt = $pdo->query("SELECT * FROM leave_requests ORDER BY createdAt DESC");
            $leaves = $leaveStmt->fetchAll();

            echo json_encode([
                'success' => true,
                'data' => [
                    'profile' => $profileData,
                    'schedule' => $scheduleData,
                    'teachers' => $teachers,
                    'holidays' => $holidays,
                    'attendanceRecords' => $attendance,
                    'leaveRequests' => $leaves,
                    'version' => time()
                ]
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'attendance':
    case 'save_attendance':
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method Not Allowed']);
            exit;
        }
        try {
            $record = $body['record'] ?? $body;
            if (empty($record['id']) || empty($record['teacherId']) || empty($record['date'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Data presensi tidak lengkap']);
                exit;
            }

            $sql = "INSERT INTO attendance_records 
                    (id, teacherId, date, checkInTime, checkOutTime, status, method, lateMinutes, earlyMinutes, notes)
                    VALUES (:id, :teacherId, :date, :checkInTime, :checkOutTime, :status, :method, :lateMinutes, :earlyMinutes, :notes)
                    ON DUPLICATE KEY UPDATE 
                    checkInTime = VALUES(checkInTime),
                    checkOutTime = VALUES(checkOutTime),
                    status = VALUES(status),
                    method = VALUES(method),
                    lateMinutes = VALUES(lateMinutes),
                    earlyMinutes = VALUES(earlyMinutes),
                    notes = VALUES(notes)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $record['id'],
                ':teacherId' => $record['teacherId'],
                ':date' => $record['date'],
                ':checkInTime' => $record['checkInTime'] ?? null,
                ':checkOutTime' => $record['checkOutTime'] ?? null,
                ':status' => $record['status'] ?? 'HADIR',
                ':method' => $record['method'] ?? $record['verificationMethod'] ?? 'FINGERPRINT',
                ':lateMinutes' => $record['lateMinutes'] ?? 0,
                ':earlyMinutes' => $record['earlyMinutes'] ?? $record['earlyLeaveMinutes'] ?? 0,
                ':notes' => $record['notes'] ?? ''
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Presensi berhasil disimpan permanen di MySQL cPanel',
                'record' => $record
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Gagal simpan presensi: ' . $e->getMessage()]);
        }
        break;

    case 'sync':
    case 'save_all_data':
        do_sync_save:
        if ($method !== 'POST') {
            http_response_code(405);
            echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
            exit;
        }
        try {
            $pdo->beginTransaction();

            // 1. Profile
            if (!empty($body['profile'])) {
                $p = $body['profile'];
                $pSql = "INSERT INTO madrasah_profile (id, name, nsm, npsn, level, status, address, village, district, regency, province, postalCode, phone, email, website, headmasterName, headmasterNip, operatorName, raw_json)
                         VALUES (1, :name, :nsm, :npsn, :level, :status, :address, :village, :district, :regency, :province, :postalCode, :phone, :email, :website, :headmasterName, :headmasterNip, 'Jaenal Maskun', :raw_json)
                         ON DUPLICATE KEY UPDATE 
                         name=VALUES(name), nsm=VALUES(nsm), npsn=VALUES(npsn), headmasterName=VALUES(headmasterName), raw_json=VALUES(raw_json)";
                $pStmt = $pdo->prepare($pSql);
                $pStmt->execute([
                    ':name' => $p['name'] ?? 'Madrasah',
                    ':nsm' => $p['nsm'] ?? '',
                    ':npsn' => $p['npsn'] ?? '',
                    ':level' => $p['level'] ?? 'MI',
                    ':status' => $p['status'] ?? 'SWASTA',
                    ':address' => $p['address'] ?? '',
                    ':village' => $p['village'] ?? '',
                    ':district' => $p['district'] ?? '',
                    ':regency' => $p['city'] ?? $p['regency'] ?? '',
                    ':province' => $p['province'] ?? '',
                    ':postalCode' => $p['postalCode'] ?? '',
                    ':phone' => $p['phone'] ?? '',
                    ':email' => $p['email'] ?? '',
                    ':website' => $p['website'] ?? '',
                    ':headmasterName' => $p['headmasterName'] ?? 'Kepala Madrasah',
                    ':headmasterNip' => $p['headmasterNip'] ?? '-',
                    ':raw_json' => json_encode($p)
                ]);
            }

            // 2. Teachers
            if (isset($body['teachers']) && is_array($body['teachers'])) {
                $teachersList = $body['teachers'];
                $validIds = [];
                foreach ($teachersList as $t) {
                    if (!empty($t['id'])) $validIds[] = $t['id'];
                }

                // Aman: Hanya lakukan INSERT atau UPDATE (Upsert), tidak menghapus guru lama yang sudah ada di database
                $tSql = "INSERT INTO teachers (id, fingerprintId, nik, nip, nuptk, pegId, name, title, position, employmentStatus, role, pin, gender, phone, email, teachingHoursPerWeek, isBiometricEnrolled, avatarColor, isActive)
                         VALUES (:id, :fingerprintId, :nik, :nip, :nuptk, :pegId, :name, :title, :position, :employmentStatus, :role, :pin, :gender, :phone, :email, :teachingHoursPerWeek, :isBiometricEnrolled, :avatarColor, :isActive)
                         ON DUPLICATE KEY UPDATE 
                         fingerprintId=VALUES(fingerprintId), nik=VALUES(nik), nip=VALUES(nip), nuptk=VALUES(nuptk), pegId=VALUES(pegId), name=VALUES(name), title=VALUES(title), position=VALUES(position), employmentStatus=VALUES(employmentStatus), role=VALUES(role), pin=VALUES(pin), gender=VALUES(gender), phone=VALUES(phone), email=VALUES(email), teachingHoursPerWeek=VALUES(teachingHoursPerWeek), isBiometricEnrolled=VALUES(isBiometricEnrolled), avatarColor=VALUES(avatarColor), isActive=VALUES(isActive)";
                $tStmt = $pdo->prepare($tSql);
                foreach ($teachersList as $t) {
                    if (empty($t['id'])) continue;
                    $tStmt->execute([
                        ':id' => $t['id'],
                        ':fingerprintId' => $t['fingerprintId'] ?? 0,
                        ':nik' => $t['nik'] ?? $t['id'],
                        ':nip' => $t['nip'] ?? '-',
                        ':nuptk' => $t['nuptk'] ?? '-',
                        ':pegId' => $t['pegId'] ?? '-',
                        ':name' => $t['name'] ?? 'Guru',
                        ':title' => $t['title'] ?? '',
                        ':position' => $t['position'] ?? 'Guru',
                        ':employmentStatus' => $t['employmentStatus'] ?? 'GTY',
                        ':role' => $t['role'] ?? 'GURU',
                        ':pin' => $t['pin'] ?? '123456',
                        ':gender' => $t['gender'] ?? 'L',
                        ':phone' => $t['phone'] ?? '-',
                        ':email' => $t['email'] ?? '',
                        ':teachingHoursPerWeek' => $t['teachingHoursPerWeek'] ?? 24,
                        ':isBiometricEnrolled' => !empty($t['isBiometricEnrolled']) ? 1 : 0,
                        ':avatarColor' => $t['avatarColor'] ?? 'bg-emerald-700',
                        ':isActive' => isset($t['isActive']) && !$t['isActive'] ? 0 : 1
                    ]);
                }
            }

            // 3. Work Schedule
            if (!empty($body['schedule'])) {
                $s = $body['schedule'];
                $sSql = "INSERT INTO work_schedules (id, workDaysCount, toleranceMinutes, raw_json)
                         VALUES (1, :workDaysCount, :toleranceMinutes, :raw_json)
                         ON DUPLICATE KEY UPDATE 
                         workDaysCount=VALUES(workDaysCount), toleranceMinutes=VALUES(toleranceMinutes), raw_json=VALUES(raw_json)";
                $sStmt = $pdo->prepare($sSql);
                $sStmt->execute([
                    ':workDaysCount' => $s['workDaysCount'] ?? 6,
                    ':toleranceMinutes' => $s['toleranceMinutes'] ?? 5,
                    ':raw_json' => json_encode($s)
                ]);
            }

            // 4. Attendance Records
            if (isset($body['attendanceRecords']) && is_array($body['attendanceRecords'])) {
                $attSql = "INSERT INTO attendance_records 
                           (id, teacherId, date, checkInTime, checkOutTime, status, method, lateMinutes, earlyMinutes, notes)
                           VALUES (:id, :teacherId, :date, :checkInTime, :checkOutTime, :status, :method, :lateMinutes, :earlyMinutes, :notes)
                           ON DUPLICATE KEY UPDATE 
                           checkInTime = VALUES(checkInTime),
                           checkOutTime = VALUES(checkOutTime),
                           status = VALUES(status),
                           method = VALUES(method),
                           lateMinutes = VALUES(lateMinutes),
                           earlyMinutes = VALUES(earlyMinutes),
                           notes = VALUES(notes)";
                $attStmt = $pdo->prepare($attSql);
                foreach ($body['attendanceRecords'] as $att) {
                    if (empty($att['id']) || empty($att['teacherId']) || empty($att['date'])) continue;
                    $attStmt->execute([
                        ':id' => $att['id'],
                        ':teacherId' => $att['teacherId'],
                        ':date' => $att['date'],
                        ':checkInTime' => $att['checkInTime'] ?? null,
                        ':checkOutTime' => $att['checkOutTime'] ?? null,
                        ':status' => $att['status'] ?? 'HADIR',
                        ':method' => $att['verificationMethod'] ?? $att['method'] ?? 'FINGERPRINT',
                        ':lateMinutes' => $att['lateMinutes'] ?? 0,
                        ':earlyMinutes' => $att['earlyLeaveMinutes'] ?? $att['earlyMinutes'] ?? 0,
                        ':notes' => $att['notes'] ?? ''
                    ]);
                }
            }

            // 5. Leave Requests
            if (isset($body['leaveRequests']) && is_array($body['leaveRequests'])) {
                $leaveSql = "INSERT INTO leave_requests 
                             (id, teacherId, type, startDate, endDate, reason, status, approvedBy)
                             VALUES (:id, :teacherId, :type, :startDate, :endDate, :reason, :status, :approvedBy)
                             ON DUPLICATE KEY UPDATE 
                             type = VALUES(type), startDate = VALUES(startDate), endDate = VALUES(endDate),
                             reason = VALUES(reason), status = VALUES(status), approvedBy = VALUES(approvedBy)";
                $leaveStmt = $pdo->prepare($leaveSql);
                foreach ($body['leaveRequests'] as $lr) {
                    if (empty($lr['id']) || empty($lr['teacherId'])) continue;
                    $leaveStmt->execute([
                        ':id' => $lr['id'],
                        ':teacherId' => $lr['teacherId'],
                        ':type' => $lr['type'] ?? 'IZIN',
                        ':startDate' => $lr['startDate'] ?? date('Y-m-d'),
                        ':endDate' => $lr['endDate'] ?? date('Y-m-d'),
                        ':reason' => $lr['reason'] ?? 'Izin',
                        ':status' => $lr['status'] ?? 'APPROVED',
                        ':approvedBy' => $lr['approvedBy'] ?? 'Kepala Madrasah'
                    ]);
                }
            }

            // 6. Log Sync
            $pdo->exec("INSERT INTO sync_logs (action, status, message) VALUES ('SYNC_ALL', 'SUCCESS', 'Sinkronisasi menyeluruh dari browser berhasil')");

            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Semua data SIMPRESENSI berhasil disinkronkan ke database MySQL cPanel (masbagoes_absensi)',
                'timestamp' => time()
            ]);
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Gagal sinkronisasi: ' . $e->getMessage()]);
        }
        break;

    default:
        try {
            $stmt = $pdo->query("SELECT 1 as test, NOW() as server_time, DATABASE() as current_db");
            $res = $stmt->fetch();
            echo json_encode([
                'success' => true,
                'status' => 'ok',
                'service' => 'simpresensi-cpanel-mysql',
                'message' => 'Endpoint API cPanel Ditemukan & Database MySQL (masbagoes_absensi) Terhubung!',
                'database' => $res['current_db'] ?: 'masbagoes_absensi',
                'user' => 'masbagoes_absensi',
                'host' => 'localhost',
                'server_time' => $res['server_time'],
                'action_received' => $action,
                'available_actions' => ['test_db', 'uji_koneksi', 'get_initial_data', 'get_teachers', 'save_attendance', 'sync_all', 'get_profile']
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'API cPanel ditemukan namun database error: ' . $e->getMessage(),
                'action' => $action
            ]);
        }
        break;
}
