<?php
// ============================================================
// SIMPRESENSI MADRASAH - DYNAMIC SSR OPEN GRAPH & ENTRY POINT (cPanel MySQL)
// ============================================================
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
    || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
    || (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on');

$protocol = $isHttps ? "https" : "http";
$host = $_SERVER['HTTP_X_FORWARDED_HOST'] ?? $_SERVER['HTTP_HOST'] ?? 'localhost';
$baseUrl = $protocol . '://' . $host;
$currentUrl = $baseUrl . ($_SERVER['REQUEST_URI'] ?? '');

$schoolName = "MI MA'ARIF NU 02 SANGGREMAN";
$cacheBuster = time();

// Fetch latest profile from MySQL (cPanel masbagoes_absensi)
try {
    require_once __DIR__ . '/config.php';
    $dsn = "mysql:host=" . (defined('DB_HOST') ? DB_HOST : 'localhost') . ";dbname=" . (defined('DB_NAME') ? DB_NAME : 'masbagoes_absensi') . ";charset=utf8mb4";
    $user = defined('DB_USER') ? DB_USER : 'masbagoes_absensi';
    $pass = defined('DB_PASS') ? DB_PASS : 'masbagus15';
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 2,
    ]);
    $stmt = $pdo->query("SELECT * FROM madrasah_profile LIMIT 1");
    $row = $stmt ? $stmt->fetch() : null;
    if ($row && !empty($row['name'])) {
        $schoolName = $row['name'];
    }
} catch (Throwable $e) {
    // Abaikan jika database belum siap, fallback aman ke nama madrasah default
}

// Dynamically locate compiled JS and CSS in ./assets/
$jsScriptTag = '';
$cssLinkTag = '';
$assetsDir = __DIR__ . '/assets';
if (is_dir($assetsDir)) {
    $files = scandir($assetsDir);
    foreach ($files as $f) {
        if (preg_match('/^index-.*\.js$/', $f)) {
            $jsScriptTag = '<script type="module" crossorigin src="./assets/' . htmlspecialchars($f) . '"></script>';
        } else if (preg_match('/^index-.*\.css$/', $f)) {
            $cssLinkTag = '<link rel="stylesheet" crossorigin href="./assets/' . htmlspecialchars($f) . '">';
        }
    }
}

$pageTitle = "SIMPRESENSI Madrasah - " . htmlspecialchars($schoolName);
$pageDesc = "Sistem Presensi Fingerprint & Rekapitulasi Laporan GTK " . htmlspecialchars($schoolName) . " Terintegrasi Kemenag & SPTJM";
$ogImageUrl = $baseUrl . "/og-image.jpg";
$ogImageSecureUrl = "https://" . $host . "/og-image.jpg";
$faviconUrl = $baseUrl . "/favicon.svg";
?>
<!doctype html>
<html lang="id" prefix="og: https://ogp.me/ns#">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="./favicon.svg" />
    <link rel="alternate icon" type="image/png" href="<?php echo $faviconUrl; ?>" />
    <link rel="apple-touch-icon" href="<?php echo $faviconUrl; ?>" />
    <link rel="image_src" href="<?php echo $ogImageUrl; ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $pageDesc; ?>" />
    
    <!-- Open Graph / WhatsApp / Facebook / Telegram Crawler Meta Tags -->
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="SIMPRESENSI GTK Madrasah" />
    <meta property="og:title" content="<?php echo $pageTitle; ?>" />
    <meta property="og:description" content="<?php echo $pageDesc; ?>" />
    <meta property="og:image" content="<?php echo $ogImageUrl; ?>" />
    <meta property="og:image:secure_url" content="<?php echo $ogImageSecureUrl; ?>" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:alt" content="<?php echo htmlspecialchars($schoolName); ?>" />

    <!-- Twitter Card Preview -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?php echo $pageTitle; ?>" />
    <meta name="twitter:description" content="<?php echo $pageDesc; ?>" />
    <meta name="twitter:image" content="<?php echo $ogImageUrl; ?>" />
    <meta name="twitter:image:alt" content="<?php echo htmlspecialchars($schoolName); ?>" />

    <?php if (!empty($cssLinkTag)): ?>
    <?php echo $cssLinkTag . "
"; ?>
    <?php endif; ?>
  </head>
  <body class="bg-zinc-100 text-zinc-900 antialiased min-h-screen">
    <div id="root"></div>
    <?php if (!empty($jsScriptTag)): ?>
    <?php echo $jsScriptTag . "
"; ?>
    <?php else: ?>
    <script type="module" crossorigin src="./assets/index.js"></script>
    <?php endif; ?>
  </body>
</html>