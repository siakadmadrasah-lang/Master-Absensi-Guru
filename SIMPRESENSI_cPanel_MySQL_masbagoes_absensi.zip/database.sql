-- ============================================================
-- SIMPRESENSI GTK MADRASAH - DATABASE SCHEMA & SEED FOR cPanel
-- Database Name : masbagoes_absensi
-- Database User : masbagoes_absensi
-- Database Host : localhost (atau IP Host cPanel)
-- Generated at  : 2026-09-19 06:58:07
-- ============================================================

CREATE DATABASE IF NOT EXISTS `masbagoes_absensi` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `masbagoes_absensi`;

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";

-- ------------------------------------------------------------
-- Table structure for `madrasah_profile` (Aman Ditimpa: Data Lama Tetap Terjaga)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `madrasah_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `nsm` varchar(50) DEFAULT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT 'MI',
  `status` varchar(50) DEFAULT 'SWASTA',
  `address` text DEFAULT NULL,
  `village` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `regency` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `postalCode` varchar(20) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `headmasterName` varchar(255) DEFAULT NULL,
  `headmasterNip` varchar(50) DEFAULT '-',
  `headmasterSignature` longtext DEFAULT NULL,
  `operatorName` varchar(255) DEFAULT 'Jaenal Maskun',
  `logoUrl` longtext DEFAULT NULL,
  `foundationLogoUrl` longtext DEFAULT NULL,
  `kemenagLogoUrl` longtext DEFAULT NULL,
  `raw_json` longtext DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `work_schedules`
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `work_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `workDaysCount` int(11) DEFAULT 6,
  `toleranceMinutes` int(11) DEFAULT 5,
  `raw_json` longtext DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `teachers` (Master GTK)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `teachers` (
  `id` varchar(64) NOT NULL,
  `fingerprintId` int(11) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nip` varchar(30) DEFAULT '-',
  `nuptk` varchar(30) DEFAULT '-',
  `pegId` varchar(30) DEFAULT '-',
  `name` varchar(255) NOT NULL,
  `title` varchar(50) DEFAULT '',
  `position` varchar(150) DEFAULT 'Guru Kelas',
  `employmentStatus` varchar(50) DEFAULT 'GTY',
  `role` varchar(50) DEFAULT 'GURU',
  `pin` varchar(50) DEFAULT '123456',
  `gender` enum('L','P') DEFAULT 'L',
  `phone` varchar(50) DEFAULT '-',
  `email` varchar(100) DEFAULT '',
  `teachingHoursPerWeek` int(11) DEFAULT 24,
  `isBiometricEnrolled` tinyint(1) DEFAULT 1,
  `avatarColor` varchar(50) DEFAULT 'bg-emerald-700',
  `isActive` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nik` (`nik`),
  KEY `idx_fingerprint` (`fingerprintId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `attendance_records`
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attendance_records` (
  `id` varchar(64) NOT NULL,
  `teacherId` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `checkInTime` varchar(20) DEFAULT NULL,
  `checkOutTime` varchar(20) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'HADIR',
  `method` varchar(50) DEFAULT 'FINGERPRINT',
  `lateMinutes` int(11) DEFAULT 0,
  `earlyMinutes` int(11) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `deviceIp` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_teacher_date` (`teacherId`, `date`),
  KEY `idx_date` (`date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `leave_requests`
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leave_requests` (
  `id` varchar(64) NOT NULL,
  `teacherId` varchar(64) NOT NULL,
  `type` varchar(50) NOT NULL,
  `startDate` date NOT NULL,
  `endDate` date NOT NULL,
  `reason` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'APPROVED',
  `documentUrl` text DEFAULT NULL,
  `approvedBy` varchar(255) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_leave_teacher` (`teacherId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `holidays`
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `holidays` (
  `id` varchar(64) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(50) DEFAULT 'NASIONAL',
  PRIMARY KEY (`id`),
  KEY `idx_holiday_date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Table structure for `sync_logs`
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `sync_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'SUCCESS',
  `message` text DEFAULT NULL,
  `synced_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- SEED DATA (INSERT IGNORE: Tidak Menghilangkan Data yang Sudah Ada di Database)
-- ------------------------------------------------------------

-- 1. Madrasah Profile (Tidak menimpa jika sudah ada)
INSERT IGNORE INTO `madrasah_profile` (`id`, `name`, `nsm`, `npsn`, `level`, `status`, `address`, `village`, `district`, `regency`, `province`, `postalCode`, `phone`, `email`, `website`, `headmasterName`, `headmasterNip`, `operatorName`, `raw_json`)
VALUES (1, 'MI MA\'ARIF NU 02 SANGGREMAN', '111233020085', '60712345', 'MI', 'SWASTA', 'Jl. Lapangan Desa Sanggreman No. 04, RT 02 RW 03', 'Sanggreman', 'Rawalo', 'Kabupaten Banyumas', 'Jawa Tengah', '53173', '(0281) 6841234', 'mimaarifnu2sanggreman@gmail.com', 'www.mimaarifnu2sanggreman.sch.id', 'Siti Rochimah, S.Pd.I.', '197805122005011004', 'Jaenal Maskun', '{"name":"MI MA\'ARIF NU 02 SANGGREMAN","level":"MI","nsm":"111233020085","npsn":"60712345","status":"SWASTA","foundationName":"LP MA\'ARIF NU KABUPATEN BANYUMAS","address":"Jl. Lapangan Desa Sanggreman No. 04, RT 02 RW 03","village":"Sanggreman","district":"Rawalo","city":"Kabupaten Banyumas","province":"Jawa Tengah","postalCode":"53173","phone":"(0281) 6841234","email":"mimaarifnu2sanggreman@gmail.com","website":"www.mimaarifnu2sanggreman.sch.id","headmasterName":"Siti Rochimah, S.Pd.I.","headmasterNip":"197805122005011004","headmasterNuptk":"7435756658200023","headmasterSignatureTitle":"Kepala Madrasah","tuAdminName":"Nurul Hidayati, S.Kom.","tuAdminNip":"198910242019032011","letterHeader1":"LEMBAGA PENDIDIKAN MA\'ARIF NU","letterHeader2":"KEMENTERIAN AGAMA REPUBLIK INDONESIA","signaturePosition":"KEPALA_KIRI_GURU_KANAN","signaturePlace":"Sanggreman","signatureLeftTitle":"Mengetahui,\\nKepala Madrasah","signatureRightTitle":"Guru Yang Bersangkutan"}');

-- 2. Work Schedule
INSERT IGNORE INTO `work_schedules` (`id`, `workDaysCount`,`toleranceMinutes`, `raw_json`)
VALUES (1, 6, 5, '{"mondayThursday":{"checkInStart":"06:00","checkInLimit":"07:15","checkOutStart":"14:00","checkOutEnd":"17:00"},"friday":{"checkInStart":"06:00","checkInLimit":"07:00","checkOutStart":"11:30","checkOutEnd":"16:00"},"saturday":{"checkInStart":"06:00","checkInLimit":"07:15","checkOutStart":"13:00","checkOutEnd":"16:30"},"toleranceMinutes":5,"workDaysCount":6}');

-- 3. Master GTK
INSERT IGNORE INTO `teachers` (`id`, `fingerprintId`, `nik`, `nip`, `nuptk`, `pegId`, `name`, `title`, `position`, `employmentStatus`, `role`, `pin`, `gender`, `phone`, `email`, `teachingHoursPerWeek`, `isBiometricEnrolled`, `avatarColor`, `isActive`)
VALUES 
('super-admin-jaenal', 999, '3302010000009999', '-', '-', '-', 'Jaenal Maskun', 'S.Pd.I.', 'Super Administrator SIMPRESENSI', 'TENAGA_KEPENDIDIKAN', 'ADMIN', 'masbagus', 'L', '081234567890', 'jaenalmaskun@gmail.com', 0, 1, 'bg-emerald-800', 1)
;

SET FOREIGN_KEY_CHECKS = 1;
