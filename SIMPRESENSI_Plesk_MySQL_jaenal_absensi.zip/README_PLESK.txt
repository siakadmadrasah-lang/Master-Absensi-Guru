======================================================================
  PANDUAN INSTALASI SIMPRESENSI MADRASAH DI PLESK CONTROL PANEL
======================================================================

Kredensial Database MySQL yang telah dikonfigurasi:
--------------------------------------------------
- Host Database     : localhost
- Database Name     : jaenal_absensi
- Database Username : jaenal_absensi
- Database Password : masbagus15

Akun Super Administrator:
--------------------------------------------------
- Email / User      : jaenalmaskun@gmail.com
- Password / PIN    : masbagus

Kepala Madrasah:
--------------------------------------------------
- Nama              : Siti Rochimah, S.Pd.I.
- PIN Default GTK   : 123456

======================================================================
LANGKAH-LANGKAH DEPLOYMENT DI PLESK:
======================================================================

LANGKAH 1: MEMBUAT DATABASE DI PLESK
1. Login ke panel Plesk Anda (https://domain-anda.com:8443).
2. Masuk ke menu "Databases" -> Klik "Add Database".
3. Masukkan data persis seperti berikut:
   - Database name: jaenal_absensi
   - Database user name: jaenal_absensi
   - Password: masbagus15 (konfirmasi: masbagus15)
4. Klik "OK" untuk membuat database.

LANGKAH 2: IMPORT FILE DATABASE (database.sql)
1. Di halaman Databases Plesk yang baru dibuat, klik tombol "phpMyAdmin".
2. Di phpMyAdmin, klik tab menu "Import" di bagian atas.
3. Klik "Choose File" dan pilih file "database.sql" yang ada di dalam paket zip ini.
4. Gulir ke bawah dan klik tombol "Go" / "Import".
5. Pastikan muncul notifikasi hijau "Import has been successfully finished".

LANGKAH 3: UPLOAD FILE KE FILE MANAGER PLESK
1. Di Plesk, buka menu "Files" -> masuk ke direktori "httpdocs" (atau folder domain Anda).
2. Jika ada file default seperti index.html bawaan Plesk, silakan hapus atau cadangkan.
3. Upload seluruh isi file dari zip ini ke dalam folder "httpdocs":
   - index.html
   - api.php
   - .htaccess
   - folder assets/ (beserta seluruh isinya: css & js)
4. Pastikan izin akses file (permissions) adalah 644 untuk file dan 755 untuk folder.

LANGKAH 4: SELESAI & UJI COBA
1. Buka domain Anda di web browser: https://domain-anda.com
2. Masuk menggunakan akun Super Admin:
   - User : jaenalmaskun@gmail.com
   - Pass : masbagus
3. SIMPRESENSI Madrasah siap digunakan secara online 24 jam!

Hubungi Tim Teknis jika memerlukan bantuan konfigurasi tambahan.
