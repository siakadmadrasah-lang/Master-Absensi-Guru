<?php
/**
 * SIMPRESENSI MADRASAH - FILE KONFIGURASI DATABASE CPANEL
 * Disesuaikan otomatis dengan kredensial cPanel MySQL
 */

return [
    'db_host' => 'localhost',
    'db_name' => 'masbagoes_absensi',
    'db_user' => 'masbagoes_absensi',
    'db_pass' => 'masbagus15',
    'db_charset' => 'utf8mb4',
    'app_name' => 'SIMPRESENSI GTK Madrasah',
    'installed_at' => date('Y-m-d H:i:s'),
];
