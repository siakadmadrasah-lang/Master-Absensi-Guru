================================================================================
SIMPRESENSI GTK MADRASAH - PAKET CPANEL & DATABASE MYSQL
================================================================================
Kredensial Database Terkonfigurasi:
- Database Name : masbagoes_absensi
- Database User : masbagoes_absensi
- Password      : masbagus15
- Database Host : localhost (atau IP Host Database cPanel)
- Port          : 3306
- Madrasah      : MI MA'ARIF NU 02 SANGGREMAN
- Total GTK     : 0 Tenaga Pendidik & Kependidikan

CARA INSTALASI CEPAT DI CPANEL:
1. BUAT DATABASE DI CPANEL:
   - Masuk ke cPanel -> Menu "MySQL® Databases"
   - Buat Database Baru dengan nama: masbagoes_absensi
   - Buat Pengguna MySQL Baru:
     Username: masbagoes_absensi
     Password: masbagus15
   - Tambahkan Pengguna Ke Database:
     Pilih User: masbagoes_absensi | Database: masbagoes_absensi
     Klik "Add" -> Centang "ALL PRIVILEGES" -> Klik "Make Changes".

2. IMPORT STRUKTUR & DATA DATABASE (phpMyAdmin):
   - Masuk ke cPanel -> Menu "phpMyAdmin"
   - Klik nama database "masbagoes_absensi" di panel kiri
   - Klik tab menu "Import" di atas
   - Klik "Choose File" / "Browse", pilih file "database.sql" dari paket ini
   - Klik tombol "Import" / "Kirim" di bagian bawah.

3. UPLOAD FILE WEBSITE KE FILE MANAGER CPANEL:
   - Masuk ke cPanel -> Menu "File Manager"
   - Buka direktori "public_html" (atau direktori subdomain Anda)
   - Unggah file ZIP ini ("SIMPRESENSI_cPanel_MySQL_masbagoes_absensi.zip")
   - Klik kanan file ZIP -> Klik "Extract"
   - Pastikan file .htaccess, index.html, api.php, dan folder assets/ berada di root public_html.

4. SELESAI & UJI COBA:
   - Buka domain madrasah Anda di browser (contoh: https://absensi.madrasah.sch.id)
   - Uji coba terminal presensi sidik jari / PIN
   - Semua presensi langsung tersimpan otomatis ke database MySQL masbagoes_absensi!
================================================================================
